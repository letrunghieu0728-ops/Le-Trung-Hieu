import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Quản lý điểm sinh viên", page_icon="📚", layout="wide")

st.title("QUẢN LÝ ĐIỂM SINH VIÊN")
st.caption("Ứng dụng quản lý, tính toán và tra cứu điểm học tập của sinh viên.")

# Dữ liệu mẫu của 10 sinh viên
data = {
    "Ho_va_ten": ["An", "Bình", "Chi", "Dũng", "Hà", "Lan", "Minh", "Nam", "Phúc", "Trang"],
    "Chuyen_can": [8.0, 9.0, 7.0, 8.5, 7.5, 6.0, 8.5, 7.0, 7.5, 9.0],
    "Giua_ky":    [7.5, 8.0, 6.5, 9.0, 7.0, 6.0, 8.5, 7.0, 7.5, 9.0],
    "Cuoi_ky":    [8.0, 8.5, 6.5, 9.5, 7.5, 6.0, 8.5, 7.5, 7.5, 9.5],
}
df = pd.DataFrame(data)

def xep_loai(diem: float) -> str:
    if diem >= 8.5:
        return "Giỏi"
    if diem >= 7.0:
        return "Khá"
    if diem >= 5.0:
        return "Trung bình"
    return "Yếu"

# Công thức: 20% chuyên cần + 30% giữa kỳ + 50% cuối kỳ
df["Tong_ket"] = (
    0.2 * df["Chuyen_can"]
    + 0.3 * df["Giua_ky"]
    + 0.5 * df["Cuoi_ky"]
)
df["Xep_loai"] = df["Tong_ket"].apply(xep_loai)

st.subheader("Bảng điểm chi tiết của 10 sinh viên")
st.dataframe(
    df.rename(columns={
        "Ho_va_ten": "Họ và tên",
        "Chuyen_can": "Chuyên cần",
        "Giua_ky": "Giữa kỳ",
        "Cuoi_ky": "Cuối kỳ",
        "Tong_ket": "Tổng kết",
        "Xep_loai": "Xếp loại",
    }).style.format({
        "Chuyên cần": "{:.1f}",
        "Giữa kỳ": "{:.1f}",
        "Cuối kỳ": "{:.1f}",
        "Tổng kết": "{:.2f}",
    }),
    use_container_width=True,
    hide_index=True,
)

st.subheader("Thống kê kết quả học tập")
col1, col2, col3 = st.columns(3)
col1.metric("Điểm tổng kết trung bình", f"{df['Tong_ket'].mean():.2f}")
max_sv = df.loc[df["Tong_ket"].idxmax()]
min_sv = df.loc[df["Tong_ket"].idxmin()]
col2.metric("Điểm cao nhất", f"{max_sv['Tong_ket']:.2f}", str(max_sv["Ho_va_ten"]))
col3.metric("Điểm thấp nhất", f"{min_sv['Tong_ket']:.2f}", str(min_sv["Ho_va_ten"]))
st.write(f"Số sinh viên đạt từ 5.0 điểm trở lên: **{int((df['Tong_ket'] >= 5.0).sum())}/{len(df)}**")

st.subheader("Biểu đồ cột điểm tổng kết")
fig, ax = plt.subplots(figsize=(10, 4.5))
ax.bar(df["Ho_va_ten"], df["Tong_ket"], color="skyblue", edgecolor="black")
ax.set_xlabel("Tên sinh viên")
ax.set_ylabel("Điểm tổng kết")
ax.set_ylim(0, 10)
ax.set_title("Biểu đồ thể hiện điểm tổng kết của 10 sinh viên")
ax.grid(axis="y", linestyle="--", alpha=0.5)
fig.tight_layout()
st.pyplot(fig)
plt.close(fig)

st.subheader("Tra cứu thông tin theo sinh viên")
chon_sv = st.selectbox("Chọn tên sinh viên:", df["Ho_va_ten"].tolist())
thong_tin_sv = df.loc[df["Ho_va_ten"] == chon_sv].iloc[0]
st.write(f"**Kết quả của {chon_sv}:**")
c1, c2, c3 = st.columns(3)
c1.write(f"**Chuyên cần:** {thong_tin_sv['Chuyen_can']:.1f}")
c2.write(f"**Giữa kỳ:** {thong_tin_sv['Giua_ky']:.1f}")
c3.write(f"**Cuối kỳ:** {thong_tin_sv['Cuoi_ky']:.1f}")
st.success(f"Điểm tổng kết: {thong_tin_sv['Tong_ket']:.2f} — Xếp loại: {thong_tin_sv['Xep_loai']}")

st.divider()
st.caption("Người tạo ứng dụng: Lê Trung Hiếu")
