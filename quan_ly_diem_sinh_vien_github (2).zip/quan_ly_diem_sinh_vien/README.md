# Quản lý điểm sinh viên

Ứng dụng Streamlit dùng để quản lý điểm mẫu của 10 sinh viên, tính điểm tổng kết, xếp loại, thống kê và tra cứu từng sinh viên.

## Công thức tính điểm

`Điểm tổng kết = 20% × Chuyên cần + 30% × Giữa kỳ + 50% × Cuối kỳ`

## Chạy ứng dụng trên máy

1. Cài Python 3.9 trở lên.
2. Mở Terminal/CMD trong thư mục dự án.
3. Cài các thư viện:

   ```bash
   pip install -r requirements.txt
   ```

4. Khởi chạy:

   ```bash
   streamlit run app.py
   ```

5. Trình duyệt sẽ mở ứng dụng Streamlit (thường tại `http://localhost:8501`).

## Đưa lên GitHub

1. Tạo repository mới trên GitHub.
2. Giải nén thư mục dự án.
3. Tải lên `app.py`, `requirements.txt`, và `README.md`; hoặc chạy:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: student grade management app"
   git branch -M main
   git remote add origin https://github.com/USERNAME/REPOSITORY.git
   git push -u origin main
   ```

Thay `USERNAME/REPOSITORY` bằng tên tài khoản và repository của bạn.
